package com.mx.develop.rest;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author said.olano@oracle.com
 */
public class Client1 {

    public static void main(String[] args) {
        String contextUrl= "http://localhost:8084/WebApplication1";
        String mapping = "/rest";
        String resourcePath = "/UserService/users";
        String urlString = contextUrl + mapping + resourcePath;
        try {
            URL url = new URL(urlString);
            InputStream result = (InputStream)url.getContent();
            Scanner scanner = new Scanner(result);
            while(scanner.hasNext()){
                System.out.println(scanner.next());
            }
            System.out.println("DONE!!!");
        } catch (MalformedURLException ex) {
            Logger.getLogger(Client1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Client1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
