package com.mx.develop.rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author said.olano@oracle.com
 */
public class Client3 {

    public static void main(String[] args) {
        String contextUrl = "http://localhost:8084/WebApplication1";
        String mapping = "/rest";
        String resourcePath = "/UserService/users";
        String urlString = contextUrl + mapping + resourcePath;
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setAllowUserInteraction(true);
            /*Sets the value of the doInput field for this URLConnection to the specified value.
            A URL connection can be used for input and/or output. 
            Set the DoInput flag to true if you intend to use the URL connection for input, false if not. 
            The default is true.
             */
            connection.setDoOutput(true);
            connection.setDoInput(true);
            OutputStream os = connection.getOutputStream();
            PrintWriter pw = new PrintWriter(os);
            //Incomplete, it needs the inputStream implementation...
            //this will be discused further...
            System.out.println("DONE!!!");
        } catch (MalformedURLException ex) {
            Logger.getLogger(Client1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Client1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
