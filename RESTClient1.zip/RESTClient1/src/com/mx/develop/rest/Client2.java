package com.mx.develop.rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author said.olano@oracle.com
 */
public class Client2 {
    public static void main(String[] args) {
        String contextUrl= "http://localhost:8084/WebApplication1";
        String mapping = "/rest";
        String resourcePath = "/UserService/users";
        String urlString = contextUrl + mapping + resourcePath;
        try {
            URL url = new URL(urlString);
            InputStream result = (InputStream)url.getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(result));
            System.out.println(reader.readLine());
            System.out.println("DONE!!!");
        } catch (MalformedURLException ex) {
            Logger.getLogger(Client1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Client1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
